/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareasclasenoviembre;

/**
 *
 * @author Airam Hernández Déniz 1ºDAM
 */
public class Practica2 {
    public static void main(String[] args) {
        
    /**
    * mi variable -> No se puede porque esta separado y la segunda palabra debería empezar por mayúscula (miVariable).
    * 
    * num_de_cte -> No recomendable porque no es clara, no se sabe a que se refiere la variable, haciendolo más dificil para entenderlo, 
    * además de que por convenio el barra baja solo se usa para separar letras mayúsculas.
    * 
    * ____programa -> No es recomendable porque empieza con _
    * 
    * 3tema -> No recomendable ya que se suele empezar por una letra en minúscula.
    * 
    * cierto? -> No se puede usar porque tiene el interrogante.
    * 
    * númerodeCliente -> Bien aunque siguiendo las reglas estrictamente sería así númeroDeCliente.
    * 
    * jose~ -> No se puede porque tiene ~ ya que se utiliza como operador.
    * 
    * año -> No recomendable porque para la gente de fuera de españa lo más probable es que no tenga la letra ñ en su teclado,
    * por lo que tendrían que copiarla y pegarla del buscador cada vez que la quisieran usar lo que lo hace muy tedioso.
    * 
    * PI -> Esta bien y es recomendable ya que poner el símbolo es mas tedioso.
    * 
    * int -> No se puede porque es una palabra reservada de Java.
    */ 
        
    }
}
