/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareasclasenoviembre;

/**
 *
 * @author Airam Hernández Déniz 1ºDAM
 */
public class Practica5 {
     public static void main(String[] args) {
     int numero = 0x10;
     System.out.println(numero);
     // Te avisa de error pero luego te da 16. Al tener el 0x lo interpreta como si fuera un hexadeciaml.

     System.out.println(067);
     //te avisa de error y luego te da 55. Al tener el 0 delante lo interpreta como un octal.
    }
}

    