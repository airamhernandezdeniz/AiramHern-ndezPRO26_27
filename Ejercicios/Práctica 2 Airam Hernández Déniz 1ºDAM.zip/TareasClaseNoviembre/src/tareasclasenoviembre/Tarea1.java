/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareasclasenoviembre;

/**
 *
 * @author Airam Hernández Déniz 1ºDAM 
 */
public class Tarea1 {
    public static void main(String[] args) {
        
        System.out.println("Hola Mundo! Soy Airam Hernández y este es mi primer programa");
        
    }
}
