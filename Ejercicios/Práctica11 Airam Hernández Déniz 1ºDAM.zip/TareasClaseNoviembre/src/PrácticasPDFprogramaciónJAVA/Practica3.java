/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrácticasPDFprogramaciónJAVA;

/**
 *
 * @author Airam Hernández Déniz 1ºDAM
 */
public class Practica3 {
    public static void main(String[] args) {
        
     /**
     * 1. Si un empleado está casado o no. -> boolean true (si esta casado) o false (si no lo esta).
     * 2. 999999. -> int porque es un número entero y se pasa del rango del short.
     * 3. Día de la semana -> Para escribir el nombre del día sería String y si se refiere a los nº del º-7 byte.
     * 4. Día del año. -> short porque se pasa del rango del byte.
     * 5. Sexo: con dos valores posibles 'V' o 'M' -> char ya que solo necesita dos caracteres.
     * 6. Milisegundos transcurridos desde el 01/01/1970 hasta nuestros días. -> long porque supera el limite de int.
     * 7. Almacenar el total de una factura -> float o double ya que permiten decimales.
     * 8. Población mundial del planeta tierra. long porque es un número extremadamente grande  supera por muchísimo el limite de int.
     */ 
    }
}
