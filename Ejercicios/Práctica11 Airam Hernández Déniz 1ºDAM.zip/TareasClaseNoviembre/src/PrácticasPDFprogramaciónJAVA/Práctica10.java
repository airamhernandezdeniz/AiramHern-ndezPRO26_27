/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrácticasPDFprogramaciónJAVA;

/**
 *
 * @author Airam
 */
public class Práctica10 {
    public static void main(String[] args) {
       int x,y;
       x=3;
       y=++x;
       System.out.println("Resultado con prefijo: x = " + x + " y = " + y);
 
       x=3;
       y=x++;
       System.out.println("Resultado con postfijo: x = " + x + " y = " + y);
       /*
       Al ejecutarlo sale esto pero creo que en clase habian dicho que tenia un error en el codigo que esta en el pdf
       porque no tiene sentido lo que te da, debería darte lo mismo ¿no?:
       
       Resultado con prefijo: x = 4 y = 4
       Resultado con postfijo: x = 4 y = 3
       */
    }
}
