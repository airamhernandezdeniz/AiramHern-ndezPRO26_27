package PrácticasPDFprogramaciónJAVA;

/**
 * @author Airam Hernábdez Déniz
 */
public class Práctica8 {
    public static void main(String[] args) {
       int entero;
       double real = 3.5;
       entero = (int)real;
       System.out.println(entero);
       //te avisa de error porque esta pasando de int a double lo que podría contener errores de perdida de contenido
       //Si lo ejecutas te da 3 ya que pasa del 3.5 que es real a convertirlo en entero lo que le quita el decimal quedando solo 3.
    }
}
