/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrácticasPDFprogramaciónJAVA;

/**
 *
 * @author Airam
 */
public class Práctica11 {
    public static void main(String[] args) {
        int x,y;        
        x= 3; 
        y= 4; 
        y *= ++x;
        System.out.println("x=" + x +" y=" + y);
        /*Al ejecutarlo sale esto: x=4 y=16
        Si no usáramos ++ ni += lo escribiriamos así:
        int x,y;        
        x= 3; 
        y= 4; 
        x = x + 1;
        y = y * x;
        System.out.println("x=" + x +" y=" + y);
        */
    }
}
