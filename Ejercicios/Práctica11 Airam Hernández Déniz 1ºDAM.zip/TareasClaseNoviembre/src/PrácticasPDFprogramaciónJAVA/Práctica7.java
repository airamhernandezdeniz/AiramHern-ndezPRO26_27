package PrácticasPDFprogramaciónJAVA;

/**
 * @author Airam Hernández Déniz
 */
public class Práctica7 {
    public static void main(String[] args) {
        final int MAXIMO = 23;
        MAXIMO = 12;
        /*te avisa de error ya que poner final antes de int hace que no se pueda modificar su valor por lo que lo ejecutamos sale error:
        run:
        Exception in thread "main" java.lang.ExceptionInInitializerError
        Caused by: java.lang.RuntimeException: Uncompilable code - class Pr�ctica7 is public, should be declared in a file named Pr�ctica7.java
	at tareasclasenoviembre.Pr�ctica7.<clinit>(Pr�ctica6.java:1)
        C:\Users\usuario\AppData\Local\NetBeans\Cache\31\executor-snippets\run.xml:111: The following error occurred while executing this line:
        C:\Users\usuario\AppData\Local\NetBeans\Cache\31\executor-snippets\run.xml:68: Java returned: 1
        BUILD FAILED (total time: 1 second)
        */
    }
}
