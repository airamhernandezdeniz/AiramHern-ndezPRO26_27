/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrácticasPDFprogramaciónJAVA;

/**
 *
 * @author Airam
 */
public class Practica4 {
    public static void main(String[] args) {
        long variable = 123400000000;
        
        /**
        * Si lo ejecutamos nos avisará de que contiene un error, si le damos a ejecutar de todas formas la consola nos pondra esto:
        * run:
        * Exception in thread "main" java.lang.RuntimeException: Uncompilable code - integer number too large
        * at tareasclasenoviembre.Practica4.main(Practica4.java:1)
        * C:\Users\usuario\AppData\Local\NetBeans\Cache\31\executor-snippets\run.xml:111: The following error occurred while executing this line:
        * C:\Users\usuario\AppData\Local\NetBeans\Cache\31\executor-snippets\run.xml:68: Java returned: 1
        * BUILD FAILED (total time: 1 second)
        *
        */
    }
}

