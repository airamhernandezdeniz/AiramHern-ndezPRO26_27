package PrácticasPDFprogramaciónJAVA;

/**
 * @author Airam Hernández Déniz 1ºDAM
 */
public class Práctica7 {
    public static void main(String[] args) {
        //hacer el horario de clase, ns como la vdd
    }
}
