/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrácticasPDFprogramaciónJAVA;

/**
 *
 * @author Airam Hernández Déniz 1ºDAM
 */
public class Práctica9 {
    public static void main(String[] args) {
        
       //por hacer
    }
}
